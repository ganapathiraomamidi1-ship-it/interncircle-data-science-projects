# Chart takeaways

- In this sample, the recorded survival rate is 74.2% for women and 18.9% for men.
- Survival rates are 63.0% in first class, 47.3% in second class, and 24.2% in third class.
- Median fares are 60.29, 14.25, and 8.05 for first, second, and third class respectively.
- The pairwise correlation between fare and recorded survival is 0.26; this is an association and does not show that fare caused survival.

The saved charts include an age histogram, survival bar chart, fare box plot, age/fare scatter plot, and numeric correlation heatmap. Box-plot outlier points are hidden only for readability.
