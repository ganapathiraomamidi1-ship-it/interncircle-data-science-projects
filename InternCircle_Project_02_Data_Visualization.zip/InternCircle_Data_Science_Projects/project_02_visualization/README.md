# Project 02 — Data Visualization

Deliverables: executed notebook, five standalone chart PNGs in `charts/`, and `takeaways.md`. Data source: the shared public Titanic sample in `../data/titanic.csv`.
