# Project 04 — First Machine Learning Classifier

Deliverables: executed notebook, reproducible train/test evaluation, serialized scikit-learn pipeline, metrics JSON, confusion matrix, and limitations note. Data source: the shared public Titanic sample.
