# Classifier results and limitations

- Dataset rows: 891
- Train/test rows: 712 / 179
- Split: 80/20, stratified, `random_state=42`
- Model: scikit-learn decision-tree pipeline, `max_depth=4`, `min_samples_leaf=10`
- Held-out accuracy: **77.7%**
- Majority-class baseline accuracy: **61.5%**
- Probability MSE (Brier score): **0.166**

Confusion matrix with rows as true outcomes and columns as predictions: true non-survivor → predicted non-survivor **101**, predicted survivor **9**; true survivor → predicted non-survivor **31**, predicted survivor **38**.

## Limitations

This historical passenger sample is small and observational. A single random split is not a robust estimate of future performance, and no feature association establishes causality. Outcomes reflect the circumstances and inequities of the 1912 disaster. This model is for learning only and must not be used to make decisions about real people.
