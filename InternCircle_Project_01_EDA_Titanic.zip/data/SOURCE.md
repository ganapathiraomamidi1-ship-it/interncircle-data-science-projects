# Public Titanic dataset source

`titanic.csv` is the public sample dataset distributed in the `mwaskom/seaborn-data` repository.

Source: https://github.com/mwaskom/seaborn-data/blob/master/titanic.csv

The source file contains 891 rows. The notebooks use it for descriptive exploration and a held-out educational classifier exercise.
