# Project 01 — EDA on Titanic

Deliverables: `eda_titanic.ipynb`, `eda_titanic.html`, and `findings.md`. The notebook uses the shared `../data/titanic.csv` dataset. It reports exact duplicate-looking rows but does not delete them without a passenger identifier.
