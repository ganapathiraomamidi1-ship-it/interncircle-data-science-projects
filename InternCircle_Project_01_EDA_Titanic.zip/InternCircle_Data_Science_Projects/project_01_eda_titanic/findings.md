# Three findings — Titanic EDA

1. **Sex:** survival was 74.2% for female records and 18.9% for male records.
2. **Passenger class:** survival was 63.0% in first class and 24.2% in third class.
3. **Age bands:** the child group (under 12) had a survival rate of 57.4%; ages 18–34 had 33.7%.

These are descriptive rates in a historical sample. They do not establish causation.
