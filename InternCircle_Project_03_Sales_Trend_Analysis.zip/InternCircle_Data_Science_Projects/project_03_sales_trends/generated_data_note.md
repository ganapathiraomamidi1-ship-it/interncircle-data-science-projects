# Generated data note

`data/ecommerce_sales_generated.csv` was created for this learning project with a fixed random seed. It contains fictional orders, customer IDs, products, dates, quantities, prices, discounts, regions, and revenue. It is not public company data, does not identify real people, and should not be described as real business performance.
