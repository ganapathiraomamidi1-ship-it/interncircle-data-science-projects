# Business brief — simulated e-commerce sales

## Executive readout

The generated 2025 sample contains **2,400 synthetic orders** and **$342,871** in simulated revenue. December is the highest-revenue month (**$72,777**). Average monthly revenue in November–December is **155.2%** higher than January–October in this constructed dataset.

## What stands out

- **Largest category:** Electronics at **$180,581** (52.7% of revenue).
- **Customer concentration:** the top 10% of fictional customers account for **72.5%** of simulated revenue.
- **Seasonality:** the year-end lift is built into the generator; it is a demonstration pattern, not a forecast or evidence of a real market trend.

## Actions to test

1. Compare November–December demand with fulfillment capacity before committing to more stock; validate with real historical orders first.
2. Test a category-specific offer for Electronics and measure contribution margin, not revenue alone.
3. Pilot a retention offer for high-spend customers and compare incremental repeat purchases with a holdout group.

**Data note:** all orders and customer IDs are synthetic and reproducible from the notebook seed. No real customer data was used.
