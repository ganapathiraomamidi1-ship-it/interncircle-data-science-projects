# Project 03 — Customer Churn / Sales Trend Analysis

Deliverables: executed notebook, generated order CSV, three charts, one-page business brief, and a generated-data note. All rows and customer IDs are synthetic; the brief labels them accordingly.
