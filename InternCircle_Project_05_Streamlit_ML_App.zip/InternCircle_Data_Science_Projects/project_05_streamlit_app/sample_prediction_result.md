# Sample prediction

Using the bundled model with the sample inputs in `sample_input.json`, the app returns an estimated probability of **40.7%** and predicts **did not survive**.

This file records a local model preview only. It is not a screenshot from a deployed app and should not be presented as one.
