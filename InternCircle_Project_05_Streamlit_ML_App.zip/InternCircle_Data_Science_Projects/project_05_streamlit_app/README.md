# Project 05 — Streamlit / Gradio Interactive ML Web App

The Streamlit app loads the Project 04 model and presents a prediction for user-entered sample features. Run with `streamlit run app.py` after installing `requirements.txt`. No live deployment or repository URL has been created.
